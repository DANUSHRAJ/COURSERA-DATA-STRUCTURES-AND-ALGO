**Divide and Conquer**
