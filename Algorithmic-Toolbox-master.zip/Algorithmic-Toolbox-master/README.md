# Algorithmic-Toolbox
My solutions for the algorithmic toolbox course on Coursera<br>
Course 1 of the specialization.<br>
Help needed for DP soln of week 6 Problem 2 feel free to create a new issue if you can help
