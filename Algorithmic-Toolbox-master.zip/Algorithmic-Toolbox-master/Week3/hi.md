**Greedy Algorithms**
